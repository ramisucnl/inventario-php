
<?php
interface IDescuento {
    public function getDescuento();
}
?>
