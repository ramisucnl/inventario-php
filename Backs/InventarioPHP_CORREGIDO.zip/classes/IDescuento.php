<?php
interface IDescuento {
    public function aplicarDescuento($porcentaje);
}
?>
