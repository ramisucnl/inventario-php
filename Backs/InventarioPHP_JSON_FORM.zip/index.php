
<?php
$json_file = "productos.json";

// Leer productos actuales
$productos = file_exists($json_file) ? json_decode(file_get_contents($json_file), true) : [];

// Procesar nuevo producto
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nombre = $_POST["nombre"] ?? "";
    $precio = floatval($_POST["precio"] ?? 0);
    $categoria = $_POST["categoria"] ?? "";

    // Calcular descuento según categoría
    $descuento = 0;
    if ($categoria === "Electrónico") {
        $descuento = $precio * 0.10;
    } elseif ($categoria === "Ropa") {
        $descuento = $precio * 0.05;
    }

    if ($nombre && $precio > 0 && $categoria) {
        $nuevo_producto = [
            "nombre" => $nombre,
            "precio" => $precio,
            "categoria" => $categoria,
            "descuento" => $descuento
        ];
        $productos[] = $nuevo_producto;
        file_put_contents($json_file, json_encode($productos, JSON_PRETTY_PRINT));
        header("Location: index.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Inventario con Formulario</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h1>Inventario (Agregar Producto)</h1>

        <form method="POST" style="margin-bottom: 30px;">
            <label>Nombre:</label><br>
            <input type="text" name="nombre" required><br><br>

            <label>Precio:</label><br>
            <input type="number" name="precio" step="0.01" required><br><br>

            <label>Categoría:</label><br>
            <select name="categoria" required>
                <option value="">Seleccione</option>
                <option value="Electrónico">Electrónico</option>
                <option value="Alimento">Alimento</option>
                <option value="Ropa">Ropa</option>
            </select><br><br>

            <button type="submit">Agregar Producto</button>
        </form>

        <table>
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Precio</th>
                    <th>Categoría</th>
                    <th>Descuento</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($productos as $producto): ?>
                    <tr>
                        <td><?= htmlspecialchars($producto['nombre']) ?></td>
                        <td>$<?= number_format($producto['precio'], 2) ?></td>
                        <td><?= htmlspecialchars($producto['categoria']) ?></td>
                        <td>$<?= number_format($producto['descuento'], 2) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
