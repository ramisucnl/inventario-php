
<?php
$json_file = "productos.json";

// Leer productos actuales
$productos = file_exists($json_file) ? json_decode(file_get_contents($json_file), true) : [];

// Eliminar producto
if (isset($_POST["eliminar"])) {
    $id = $_POST["eliminar"];
    if (isset($productos[$id])) {
        unset($productos[$id]);
        $productos = array_values($productos); // Reindexar
        file_put_contents($json_file, json_encode($productos, JSON_PRETTY_PRINT));
    }
    header("Location: index.php");
    exit;
}

// Editar producto
if (isset($_POST["editar_id"])) {
    $editando = true;
    $edit_id = $_POST["editar_id"];
    $producto_actual = $productos[$edit_id];
} else {
    $editando = false;
}

// Guardar cambios del formulario (crear o actualizar)
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["guardar"])) {
    $nombre = $_POST["nombre"] ?? "";
    $precio = floatval($_POST["precio"] ?? 0);
    $categoria = $_POST["categoria"] ?? "";
    $id_editar = $_POST["id"] ?? null;

    // Calcular descuento
    $descuento = 0;
    if ($categoria === "Electrónico") {
        $descuento = $precio * 0.10;
    } elseif ($categoria === "Ropa") {
        $descuento = $precio * 0.05;
    }

    if ($nombre && $precio > 0 && $categoria) {
        $nuevo_producto = [
            "nombre" => $nombre,
            "precio" => $precio,
            "categoria" => $categoria,
            "descuento" => $descuento
        ];

        if ($id_editar !== null && is_numeric($id_editar)) {
            $productos[intval($id_editar)] = $nuevo_producto;
        } else {
            $productos[] = $nuevo_producto;
        }

        file_put_contents($json_file, json_encode($productos, JSON_PRETTY_PRINT));
        header("Location: index.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Inventario CRUD</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <h1>Inventario (Crear, Editar, Eliminar)</h1>

        <form method="POST" style="margin-bottom: 30px;">
            <input type="hidden" name="id" value="<?= $editando ? $edit_id : '' ?>">
            <label>Nombre:</label><br>
            <input type="text" name="nombre" value="<?= $editando ? htmlspecialchars($producto_actual['nombre']) : '' ?>" required><br><br>

            <label>Precio:</label><br>
            <input type="number" name="precio" step="0.01" value="<?= $editando ? $producto_actual['precio'] : '' ?>" required><br><br>

            <label>Categoría:</label><br>
            <select name="categoria" required>
                <option value="">Seleccione</option>
                <option value="Electrónico" <?= $editando && $producto_actual['categoria'] === 'Electrónico' ? 'selected' : '' ?>>Electrónico</option>
                <option value="Alimento" <?= $editando && $producto_actual['categoria'] === 'Alimento' ? 'selected' : '' ?>>Alimento</option>
                <option value="Ropa" <?= $editando && $producto_actual['categoria'] === 'Ropa' ? 'selected' : '' ?>>Ropa</option>
            </select><br><br>

            <button type="submit" name="guardar"><?= $editando ? 'Actualizar' : 'Agregar' ?> Producto</button>
        </form>

        <table>
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Precio</th>
                    <th>Categoría</th>
                    <th>Descuento</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($productos as $index => $producto): ?>
                    <tr>
                        <td><?= htmlspecialchars($producto['nombre']) ?></td>
                        <td>$<?= number_format($producto['precio'], 2) ?></td>
                        <td><?= htmlspecialchars($producto['categoria']) ?></td>
                        <td>$<?= number_format($producto['descuento'], 2) ?></td>
                        <td>
                            <form method="POST" style="display:inline;">
                                <input type="hidden" name="editar_id" value="<?= $index ?>">
                                <button type="submit">✏️</button>
                            </form>
                            <form method="POST" style="display:inline;" onsubmit="return confirm('¿Eliminar este producto?');">
                                <input type="hidden" name="eliminar" value="<?= $index ?>">
                                <button type="submit">🗑️</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
